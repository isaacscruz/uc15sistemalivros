
package com.cultura.sistemalivross;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemalivrossApplication {

    public static void main(String[] args) {
        SpringApplication.run(SistemalivrossApplication.class, args);
    }
}